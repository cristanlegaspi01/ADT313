import React, { useRef } from 'react';
function Problem3() {
  const inputRefs = [
    useRef(null),
    useRef(null),
    useRef(null),
    useRef(null),
    useRef(null),
    useRef(null),
    useRef(null),
    useRef(null),
    useRef(null),
    useRef(null),
  ];
  const handleFocusEmptyInput = () => {
    for (let i = 0; i < inputRefs.length; i++) {
      if (inputRefs[i].current && inputRefs[i].current.value === '') {
        inputRefs[i].current.focus(); 
        break; 
      }
    }
  };
  return (
    <>
      <div style={{ display: 'block' }}>
        Input 1: <input type="text" ref={inputRefs[0]} />
      </div>
      <div style={{ display: 'block' }}>
        Input 2: <input type="text" ref={inputRefs[1]} />
      </div>
      <div style={{ display: 'block' }}>
        Input 3: <input type="text" ref={inputRefs[2]} />
      </div>
      <div style={{ display: 'block' }}>
        Input 4: <input type="text" ref={inputRefs[3]} />
      </div>
      <div style={{ display: 'block' }}>
        Input 5: <input type="text" ref={inputRefs[4]} />
      </div>
      <div style={{ display: 'block' }}>
        Input 6: <input type="text" ref={inputRefs[5]} />
      </div>
      <div style={{ display: 'block' }}>
        Input 7: <input type="text" ref={inputRefs[6]} />
      </div>
      <div style={{ display: 'block' }}>
        Input 8: <input type="text" ref={inputRefs[7]} />
      </div>
      <div style={{ display: 'block' }}>
        Input 9: <input type="text" ref={inputRefs[8]} />
      </div>
      <div style={{ display: 'block' }}>
        Input 10: <input type="text" ref={inputRefs[9]} />
      </div>
      <button type="button" onClick={handleFocusEmptyInput}>
        I'm a button 
      </button>
    </>
  );
}
export default Problem3;